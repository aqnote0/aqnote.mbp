/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP Debian 4.9.110-1 (2018-07-05)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 6.3.0 20170516 (Debian 6.3.0-18+deb9u1) "
